﻿namespace MauiClassLibrary.Issue1050
{
    // All the code in this file is included in all platforms.
    public class Class1
    {
    }
}
